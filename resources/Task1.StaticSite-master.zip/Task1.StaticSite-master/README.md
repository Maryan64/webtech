# Task1.StaticSite
